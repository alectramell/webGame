import os
import sys
import socket
import platform

from PyQt4.QtWebKit import * #QWebView
from PyQt4.QtGui import * #QApplication
from PyQt4.QtCore import * #QUrl

xtitle = "GAME v1.0"

os.system("cd game && nohup php -S localhost:8888 &")

app = QApplication(sys.argv)

browser = QWebView()
browser.resize(500, 500)
browser.setWindowTitle(xtitle)
browser.load(QUrl("http://localhost:8888"))
browser.show()

app.exec_()

os.system("killall php")
