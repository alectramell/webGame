<?php
	$xtitle = 'GAME v1.0';
?>
<html>
<head>
<title>
<?php echo $xtitle; ?>
</title>
<link type="text/css" rel="stylesheet" href="css/main.css">
<script type="text/javascript" src="js/index.js"></script>
</head>
<body>

<font id="statusText">Press [ENTER] to begin..</font>

</body>
</html>
