function startGame() {

	document.getElementById('statusText').style.display = 'none';
	document.body.style.backgroundImage = 'url(img/coin.gif)';
}

function getKey(event) {

	var xkey = event.keyCode;

	if ( xkey == "13" ) {

		startGame();

	} else {

		// do nothing..
	}
}

document.addEventListener("keypress", getKey);
